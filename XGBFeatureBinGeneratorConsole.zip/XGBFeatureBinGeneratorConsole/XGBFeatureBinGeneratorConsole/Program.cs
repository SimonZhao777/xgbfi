﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OfficeOpenXml;
using System.IO;
//using Microsoft.Office.Interop;
//using Microsoft.Office.Interop.Excel;

namespace XGBFeatureBinGeneratorConsole
{
    class Program
    {
        static void Main(string[] args)
        {
            Program p = new Program();
            p.Run();

        }

        public void Run()
        {
            Console.WriteLine("Program run!");


            string fileName = "D:\\VisualStudioProjects\\XGBFeatureBinGeneratorConsole\\XgbFeatureInteractions.xlsx";
            string userBinDirectory = "D:\\VisualStudioProjects\\XGBFeatureBinGeneratorConsole\\userFeatureBins";
            string prodBinDirectory = "D:\\VisualStudioProjects\\XGBFeatureBinGeneratorConsole\\prodFeatureBins";
            Console.WriteLine("Source file path: " + fileName);
            Console.WriteLine("user bin files output directory: " + userBinDirectory);
            Console.WriteLine("product bin files output directory: " + userBinDirectory);

            if (!File.Exists(fileName))
            {
                Console.WriteLine("Unable to find file: " + fileName);
                //Console.ReadKey();
                return;
            }

            double defaultBinMinimumBoundary = -9999.99; // 桶的默认最小边界
            double defaultBinMaximumBoundary = 11111111.11; // 桶的默认最大边界
            int maxBinNum = 10; // 每个特征的最大桶数（不包含两边的虚界）
            Console.WriteLine("min bin boundary: " + defaultBinMinimumBoundary);
            Console.WriteLine("max bin boundary: " + defaultBinMaximumBoundary);
            Console.WriteLine("max bin number: " + maxBinNum);

            List<string> categoricalFeatureKeyWords = new List<string>() { "Pattern", "tag", "line", "Level", "Salemode", "TravelDays", "category", "u_pref", "Crown", "Grade", "Vip" };
            List<string> userFeatureKeyWords = new List<string>() { "u_pref", "user_" };


            FileInfo newFile = new FileInfo(fileName);
            ExcelPackage pck = new ExcelPackage(newFile);

            //int numSheets = pck.Workbook.Worksheets.Count;

            // 得到'Split Value Histograms' Sheet 并计算有数据表格的Range
            ExcelWorksheet workSheet = pck.Workbook.Worksheets["Split Value Histograms"];
            int featureNum = workSheet.Dimension.Columns / 2;
            int maxRowNum = workSheet.Dimension.Rows;
            Console.WriteLine("feature number: " + featureNum);
            Console.WriteLine("max row number: " + maxRowNum);

            // 将'Split Value Histograms' Sheet里所有的数据load至该数据结构中
            Dictionary<string, List<SplitStruct>> dictSVHSheetFeaturesSplitData = new Dictionary<string, List<SplitStruct>>();
            // 将分好的bin存在该数据结构中
            Dictionary<string, BinStruct> dictSVHSheetFeaturesBinData = new Dictionary<string, BinStruct>();

            Console.WriteLine("Start to parse source file.");
            // 对每个特征做循环
            for (int col = 0; col < featureNum; col++)
            {
                int c1 = col * 2 + 1; // 每个特征的第一列号
                int c2 = c1 + 1; // 每个特征的第二列号

                string featureName = workSheet.Cells[1, c1].Value.ToString();
                int SumReferencedCountToTheSplit = 0; // 之前（小于该split值的所有split）所有split到该split总共被引用的次数
                int featureSplitValueCount = 0; // 当前特征的不同split value数

                // 在每个特征下对每一行做循环
                for (int row = 2; row < maxRowNum; row++)
                {
                    double splitValue = 0.0; // split 值
                    int splitReferencedCount = 0; // split 被引用的次数
                    if (null == workSheet.Cells[row, c1].Value || null == workSheet.Cells[row, c2].Value) break; // 如果下一个单元格为空则直接跳出row循环，直接进入下一个特征。
                    bool splitValueParseSuccess = double.TryParse(workSheet.Cells[row, c1].Value.ToString(), out splitValue);
                    bool splitCountParseSuccess = int.TryParse(workSheet.Cells[row, c2].Value.ToString(), out splitReferencedCount);
                    // 如果发现已经没有数据了会提前结束本循环
                    if (!splitValueParseSuccess || !splitCountParseSuccess)
                    {
                        Console.WriteLine("Split Value or Split Count parse failed at cell: [" + row + ", " + c1 + "]");
                        break;
                    }
                    else
                    {
                        // 每下一个row，总引用计数就加上上一个的split的引用计数
                        SumReferencedCountToTheSplit += splitReferencedCount;
                        // 每下一个row，split value数加1
                        featureSplitValueCount++;
                        if (!dictSVHSheetFeaturesSplitData.ContainsKey(featureName))
                        {
                            dictSVHSheetFeaturesSplitData.Add(featureName, new List<SplitStruct>());
                        }
                        dictSVHSheetFeaturesSplitData[featureName].Add(new SplitStruct(splitValue, splitReferencedCount, SumReferencedCountToTheSplit));
                    }
                }

                BinStruct newBin = new BinStruct();
                newBin.FeatureName = featureName;
                newBin.IsCategorical = false;
                newBin.SplitValues = new List<double>();
                // 根据特征名称判断是否为离散特征
                foreach (string categoricalKeyWord in categoricalFeatureKeyWords)
                {
                    if (newBin.FeatureName.ToLower().Contains(categoricalKeyWord.ToLower()))
                    {
                        newBin.IsCategorical = true;
                        break;
                    }
                }

                // 只为连续特征分桶，离散特征比较少，且都有分好的桶。
                if (!newBin.IsCategorical)
                {
                    // 如果分桶数小于maxBinNum，则每个为一个桶
                    if (featureSplitValueCount <= maxBinNum)
                    {
                        // 在两端加上默认的最大最小值
                        newBin.SplitValues.Add(defaultBinMinimumBoundary);
                        for (int i = 0; i < featureSplitValueCount; i++)
                        {
                            newBin.SplitValues.Add(dictSVHSheetFeaturesSplitData[featureName][i].SplitValue);
                        }
                        newBin.SplitValues.Add(defaultBinMaximumBoundary);
                    }
                    // 如果分桶数大于maxBinNum，则等频分割为maxBinNum个桶
                    else
                    {
                        double interval = dictSVHSheetFeaturesSplitData[featureName].Last().SumReferencedCountToTheSplit / (double)maxBinNum;
                        // 固定的将默认最小值至最小split数值设为第一个桶
                        newBin.SplitValues.Add(defaultBinMinimumBoundary);
                        newBin.SplitValues.Add(dictSVHSheetFeaturesSplitData[featureName][0].SplitValue);
                        int j = 1;
                        for (int i = 0; i < featureSplitValueCount-1; i++)
                        {
                            int sumRefCountToTheSplit = dictSVHSheetFeaturesSplitData[featureName][i].SumReferencedCountToTheSplit;
                            if (sumRefCountToTheSplit >= j * interval) //  **************核心算法: 将split累计引用数(sumRefCountToTheSplit)大于等于等频距离(interval)的设置为桶边界*****************
                            {
                                newBin.SplitValues.Add(dictSVHSheetFeaturesSplitData[featureName][i].SplitValue);
                                j++;
                            }
                        }
                        // 固定的将默认最大值至最大split数值设为最后一个桶
                        newBin.SplitValues.Add(dictSVHSheetFeaturesSplitData[featureName][featureSplitValueCount-1].SplitValue);
                        newBin.SplitValues.Add(defaultBinMaximumBoundary);
                    }

                    // 将分好的桶数据放入该数据结构中
                    dictSVHSheetFeaturesBinData.Add(featureName, newBin);
                }
            }
            Console.WriteLine("Source file parsed successfully.");

            // 创建bin文件
            Console.WriteLine("Start to write bin files.");
            CreateBinFiles(userBinDirectory, prodBinDirectory, userFeatureKeyWords, dictSVHSheetFeaturesBinData);


            /*
            Worksheet sh;
            long lastRow;
            long fullRow;

            //Workbooks workBooks = new Workbooks();
            Application xlApp = new Application();
            Workbooks xlWorkbooks = xlApp.Workbooks;
            Workbook xlWorkbook = xlWorkbooks.Open("D:\\VisualStudioProjects\\XGBFeatureBinGeneratorConsole\\XgbFeatureInteractions.xlsx");
            Sheets xlSheets = xlWorkbook.Sheets;

            Worksheet xlSheet = xlSheets["Split Value Histograms"] as Worksheet;

            int Rows = xlSheet.Rows[1].Cells.Count;
            int Cols = xlSheet.Columns[1].Cells.Count;
            //lastRow = xlSheet.Cells[fullRow, 1].get_End(XlDirection.xlUp).Row;

            Range firstCol = xlSheet.Columns[1].Cells[1, 1].End[XlDirection.xlUp];
            int fNamesCount = firstCol.Count;
            */

            Console.WriteLine("Suceedded! Press any key to continue.");
            Console.ReadKey();

        }

        public void WriteToFile(string filePath, List<double> binBoundaries)
        {
            FileStream fs = File.Create(filePath);
            fs.Close();
            StreamWriter streamWriter = new StreamWriter(filePath);
            int binBoundaryCount = binBoundaries.Count();
            for (int i = 0; i < binBoundaryCount; i++)
            {
                streamWriter.WriteLine(binBoundaries[i]);
            }
            streamWriter.Close();
        }

        public bool DeleteADirectory(string strPath)
        {
            string[] strTemp;
            try
            {
                //先删除该目录下的文件
                strTemp = System.IO.Directory.GetFiles(strPath);
                foreach (string str in strTemp)
                {
                    System.IO.File.Delete(str);
                }
                //删除子目录，递归
                strTemp = System.IO.Directory.GetDirectories(strPath);
                foreach (string str in strTemp)
                {
                    DeleteADirectory(str);
                }
                //删除该目录
                System.IO.Directory.Delete(strPath);
                return true;
            }
            catch (Exception ex)
            {
                Console.WriteLine("Failed to delete directory: " + strPath);
                //MessageBox.Show(ex.Message, "发生错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
        }

        public void CreateBinFiles(string userBinDirectory, string prodBinDirectory, List<string> userFeatureKeyWords, Dictionary<string, BinStruct> dictSVHSheetFeaturesBinData)
        {
            // 将所有桶输出成.txt文件放入相应的文件夹
            if (Directory.Exists(userBinDirectory)) { DeleteADirectory(userBinDirectory); }
            Directory.CreateDirectory(userBinDirectory);
            if (Directory.Exists(prodBinDirectory)) { DeleteADirectory(prodBinDirectory); }
            Directory.CreateDirectory(prodBinDirectory);

            foreach (KeyValuePair<string, BinStruct> bin in dictSVHSheetFeaturesBinData)
            {
                // 判断是否为用户特征
                bool isUserFeature = false;
                string featureName = bin.Key;
                BinStruct binStruct = bin.Value;
                List<Double> binBoundaries = binStruct.SplitValues;

                foreach (string ufKeyWord in userFeatureKeyWords)
                {
                    // 如果是用户特征，则输出至用户分桶文件夹内
                    if (featureName.ToLower().Contains(ufKeyWord.ToLower()))
                    {
                        string filePath = userBinDirectory + "\\" + featureName.ToLower() + ".txt";
                        WriteToFile(filePath, binBoundaries);
                        isUserFeature = true;
                        break;
                    }
                }
                // 如果是产品特征，输入产品分桶文件内
                if (!isUserFeature)
                {
                    string filePath = prodBinDirectory + "\\" + featureName.ToLower() + ".txt";
                    WriteToFile(filePath, binBoundaries);
                    isUserFeature = false;
                }
            }
        }
    }

    public struct SplitStruct
    {
        public SplitStruct(double splitValue, int splitReferencedCount, int sumReferencedCountToTheSplit)
        {
            SplitValue = splitValue;
            SplitReferencedCount = splitReferencedCount;
            SumReferencedCountToTheSplit = sumReferencedCountToTheSplit;
        }
        public double SplitValue { get; set; }
        public int SplitReferencedCount { get; set; }
        public int SumReferencedCountToTheSplit { get; set; }
    }

    public struct BinStruct
    {
        public string FeatureName { get; set; }
        public bool IsCategorical { get; set; }
        public List<double> SplitValues { get; set; }
    }
}
